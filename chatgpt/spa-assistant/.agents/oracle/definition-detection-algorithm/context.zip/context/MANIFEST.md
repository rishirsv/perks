# Oracle context manifest

- Created (UTC): 2026-01-29T21:25:31.500678+00:00
- Repo root: /Users/rishi/Code/chatgpt/spa-assistant
- Files included: 7
- Total raw size (before zip): 443.0 KB

## Task summary
Improve SPA definition-start detection + parsing algorithm + term-map.yml

## Constraints / preferences
- Prefer tweaks to dist/extract-definitions.md; improve dist/term-map.yml as a maintainable synonym/validation aid; handle DOCX quirks like '“Indebtedness” of any Person means' and multi-paragraph bullet definitions

## How to verify locally
If you want to confirm the advice locally, these checks/commands are relevant:

- `N/A (design review)`

## Excludes applied
- Default excludes: disabled (`--no-default-excludes`).
- Custom exclude patterns:
  - `**/.venv-docx/**`

## Largest files (by raw size)
- `reference/1376-6710-5562-v1-Project Thunderstruck - Share Purchase Agreement - Draft to LCL.docx` — 229.2 KB
- `reference/13.1.4 Draft Share Purchase Agreement - Project Dragon.docx` — 189.0 KB
- `dist/extract-definitions.md` — 9.2 KB
- `docs/definitions-extractor/plan-definitions-extractor.md` — 7.7 KB
- `dist/term-map.yml` — 4.3 KB

## Files
- `.agents/oracle/definition-detection-algorithm/observed-issues.md` — Verbatim observed model response + concrete formatting example
- `dist/extract-definitions.md` — Current extraction algorithm spec
- `dist/spa-assistant.md` — System prompt that references extraction workflow
- `dist/term-map.yml` — Current term map that oracle should improve
- `docs/definitions-extractor/plan-definitions-extractor.md` — Notes on deterministic extractor tool design
- `reference/13.1.4 Draft Share Purchase Agreement - Project Dragon.docx` — Sample SPA DOCX with core economics definitions
- `reference/1376-6710-5562-v1-Project Thunderstruck - Share Purchase Agreement - Draft to LCL.docx` — Sample SPA DOCX with '“Indebtedness” of any Person means' formatting

## Notes
- `prompt.md` is intentionally excluded; paste it separately into ChatGPT Pro.
- Treat files as authoritative; prefer citing exact paths when making claims.
