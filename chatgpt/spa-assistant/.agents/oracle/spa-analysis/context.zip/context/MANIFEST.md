# Context Package: BWAY Corporation SPA Analysis

## Task
Analyze BWAY Corporation SPA Key Financial Definitions to produce gold-standard example output.

## Constraint
Use only what can be supported from the actual document.

## Contents

| File | Purpose |
|------|---------|
| `spec-spa-assistant.md` | Specification for the SPA analysis tool being built |
| `BWAY-CORPORATION.pdf` | The SPA to analyze (Stock Purchase Agreement, 2009) |

## Reading Order
1. Read this manifest first
2. Review `spec-spa-assistant.md` to understand the tool being built
3. Analyze `BWAY-CORPORATION.pdf` per the prompt instructions
