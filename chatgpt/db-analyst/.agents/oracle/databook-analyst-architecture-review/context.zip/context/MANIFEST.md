# Oracle context manifest

- Created (UTC): 2026-02-21T22:59:36.914802+00:00
- Repo root: /Users/rishi/Code/ai-tools
- Files included: 22
- Total raw size (before zip): 123.0 KB

## Task summary
Review current databook-analyst skill architecture and propose simpler, stronger 2-3 alternative architectures with file-level structure and contents.

## Constraints / preferences
- Analyze current Plan/Execute contract and runner pipeline behavior.
- Propose alternatives that improve simplicity, extensibility, and testability without unnecessary infrastructure.

## How to verify locally
If you want to confirm the advice locally, these checks/commands are relevant:

- `python -m unittest chatgpt/db-analyst/.agents/skills/db-analyst/scripts/tests/test_process_tb_pipeline.py`

## Excludes applied
- Default excluded directories: .git, .next, .pytest_cache, .turbo, __pycache__, build, coverage, dist, node_modules, tmp
- Default excluded file names: .DS_Store
- Custom exclude patterns:
  - `**/__pycache__/**`
  - `**/*.pyc`
  - `**/*.xlsx`

## Largest files (by raw size)
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/build_fs_workbook.py` — 19.5 KB
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/run_qc_checks.py` — 15.4 KB
- `chatgpt/db-analyst/.agents/skills/db-analyst/references/formatting-guidelines.md` — 11.9 KB
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/tests/test_process_tb_pipeline.py` — 10.2 KB
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/ingest_tb.py` — 10.1 KB

## Files
- `chatgpt/db-analyst/.agents/skills/db-analyst/assets/template-manifest.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/README.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/references/formatting-guidelines.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/references/module-playbooks/Process-lease.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/references/module-playbooks/Process-TB.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/references/README.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/apply_coa_mapping.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/build_fs_workbook.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/build_is_trend.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/ingest_tb.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/ProcessLease.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/ProcessTB.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/README.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/run_qc_checks.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/samples/coa_mapping_process_tb_sample.csv` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/samples/coa_mapping_sample.csv` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/samples/leases_sample.csv` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/samples/tb_sample.csv` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/scripts/tests/test_process_tb_pipeline.py` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/.agents/skills/db-analyst/SKILL.md` — Primary skill contract, playbooks, scripts, tests, and templates
- `chatgpt/db-analyst/docs/spec-databook-analyst.md` — Current product specification and intended behavior
- `chatgpt/db-analyst/vdr/README.md` — Sample data-room context and assumptions

## Notes
- `prompt.md` is intentionally excluded; paste it separately into ChatGPT Pro.
- Treat files as authoritative; prefer citing exact paths when making claims.
