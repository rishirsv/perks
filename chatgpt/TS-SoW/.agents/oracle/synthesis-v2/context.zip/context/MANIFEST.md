# Oracle context manifest

- Created (UTC): 2026-01-30T18:36:38.784557+00:00
- Repo root: /Users/rishi/Code/chatgpt/TS-SoW
- Files included: 15
- Total raw size (before zip): 447.7 KB

## Task summary
Merge 11 industry FDD mining outputs into a unified scope library, following 9 explicit rules to fix previous synthesis failures

## Constraints / preferences
- Must produce exactly 11 common skeleton sections, ≥70% bullet coverage per industry, de-identified proper nouns, cross-industry revenue defaults

## How to verify locally
If you want to confirm the advice locally, these checks/commands are relevant:

- `python3 -c "import json; d=json.load(open('reference/fdd_scope_library.json')); assert len(d['common_skeleton'])==11; assert len(d['industry_modules'])==11; print('PASS')"`

## Excludes applied
- Default excluded directories: .git, .next, .pytest_cache, .turbo, __pycache__, build, coverage, dist, node_modules, tmp
- Default excluded file names: .DS_Store

## Largest files (by raw size)
- `docs/mining/hvac.json` — 81.8 KB
- `reference/fdd_scope_library.json` — 79.6 KB
- `docs/mining/manufacturing.json` — 63.0 KB
- `docs/mining/healthcare.json` — 42.9 KB
- `docs/mining/tech.json` — 29.8 KB

## Files
- `docs/mining/audit-mapping.md` — Heading mapping audit across industries
- `docs/mining/audit-verification-results.md` — Previous audit results showing what failed
- `docs/mining/construction.json` — Construction industry mining output
- `docs/mining/eyecare.json` — Eyecare industry mining output
- `docs/mining/healthcare.json` — Healthcare industry mining output
- `docs/mining/hvac.json` — HVAC industry mining output
- `docs/mining/manufacturing.json` — Manufacturing industry mining output
- `docs/mining/prof-services.json` — Prof Services industry mining output
- `docs/mining/PROMPT_synthesis-v2.md` — Detailed synthesis rules (9 rules)
- `docs/mining/real-estate.json` — Real estate industry mining output
- `docs/mining/service.json` — Service industry mining output
- `docs/mining/supermarket.json` — Supermarket industry mining output
- `docs/mining/tech.json` — Tech industry mining output
- `docs/mining/transportation.json` — Transportation industry mining output
- `reference/fdd_scope_library.json` — Previous failed synthesis for reference

## Notes
- `prompt.md` is intentionally excluded; paste it separately into ChatGPT Pro.
- Treat files as authoritative; prefer citing exact paths when making claims.
